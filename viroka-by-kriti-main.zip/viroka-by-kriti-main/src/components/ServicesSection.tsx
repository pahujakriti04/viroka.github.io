import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Flower2, Camera, Utensils, Music, Palette, Heart } from "lucide-react";

const ServicesSection = () => {
  const services = [
    {
      icon: <Flower2 className="w-8 h-8" />,
      title: "Complete Wedding Planning",
      description: "From engagement to reception, we handle every detail with care and cultural sensitivity.",
      features: ["Venue Selection", "Vendor Coordination", "Timeline Management", "Day-of Coordination"]
    },
    {
      icon: <Palette className="w-8 h-8" />,
      title: "Traditional Decorations",
      description: "Authentic mandap designs, floral arrangements, and decor that honor Indian wedding traditions.",
      features: ["Mandap Design", "Floral Arrangements", "Lighting Design", "Traditional Elements"]
    },
    {
      icon: <Camera className="w-8 h-8" />,
      title: "Photography & Videography",
      description: "Capturing precious moments and emotions with our network of talented photographers.",
      features: ["Pre-wedding Shoots", "Ceremony Coverage", "Reception Documentation", "Family Portraits"]
    },
    {
      icon: <Utensils className="w-8 h-8" />,
      title: "Catering & Cuisine",
      description: "Authentic Indian cuisine that delights your guests and honors your regional traditions.",
      features: ["Menu Planning", "Dietary Accommodations", "Regional Specialties", "Presentation Styling"]
    },
    {
      icon: <Music className="w-8 h-8" />,
      title: "Entertainment Coordination",
      description: "Traditional music, dance performances, and entertainment that celebrates your culture.",
      features: ["DJ Services", "Live Musicians", "Dance Performances", "Cultural Programs"]
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Family Coordination",
      description: "Ensuring all family members feel included and honored throughout the celebration.",
      features: ["Family Meetings", "Ritual Guidance", "Guest Coordination", "Cultural Consultation"]
    }
  ];

  return (
    <section className="py-20 bg-gradient-warm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-6">
            Services Crafted with <span className="text-wedding-orange">Love</span> & <span className="text-wedding-magenta">Tradition</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Every service is designed to honor your heritage while creating an unforgettable celebration 
            that brings families together in joy and love.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="group bg-card hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-0 shadow-lg">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 p-3 bg-gradient-sunset rounded-full text-white group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <CardTitle className="text-xl font-semibold text-card-foreground group-hover:text-wedding-orange transition-colors">
                  {service.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {service.description}
                </p>
                
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-wedding-gold rounded-full mr-3 flex-shrink-0"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-block bg-card p-8 rounded-2xl shadow-elegant">
            <h3 className="text-2xl font-bold text-card-foreground mb-4">
              Let's Plan Your Perfect Day Together
            </h3>
            <p className="text-muted-foreground mb-6 max-w-lg">
              Every wedding is unique, and our services are tailored to your specific needs, traditions, and dreams.
            </p>
            <button className="bg-gradient-sunset text-white px-8 py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-wedding-orange/25 hover:scale-105 transition-all duration-300">
              Get Your Custom Quote
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
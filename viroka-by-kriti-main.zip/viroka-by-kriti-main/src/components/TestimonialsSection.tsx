import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Arjun & Meera Patel",
      location: "Mumbai",
      text: "Kriti made our dream wedding come true. Every detail was perfect, from the traditional mandap to the modern reception. Our families still talk about how magical it was.",
      rating: 5,
      ceremony: "Hindu Traditional Wedding"
    },
    {
      name: "Rahul & Kavya Singh",
      location: "Delhi",
      text: "We were overwhelmed planning a wedding from abroad, but Kriti handled everything with such grace and understanding. She honored our Punjabi traditions beautifully.",
      rating: 5,
      ceremony: "Punjabi Wedding"
    },
    {
      name: "Vikram & Anjali Sharma",
      location: "Bangalore",
      text: "The attention to detail was incredible. Kriti understood our vision and brought it to life in ways we never imagined. Our families felt so welcomed and honored.",
      rating: 5,
      ceremony: "South Indian Wedding"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-6">
            Stories of <span className="text-wedding-orange">Joy</span> & <span className="text-wedding-magenta">Gratitude</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            The greatest reward is seeing families come together and witnessing the pure joy 
            in our couples' eyes on their special day.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="group bg-card hover:shadow-xl transition-all duration-500 hover:-translate-y-2 border-0 shadow-lg relative overflow-hidden">
              {/* Decorative gradient border */}
              <div className="absolute inset-0 bg-gradient-sunset p-[2px] rounded-lg">
                <div className="bg-card rounded-lg h-full w-full" />
              </div>
              
              <CardContent className="relative p-8 h-full flex flex-col">
                {/* Quote icon */}
                <Quote className="w-8 h-8 text-wedding-gold mb-4 opacity-50" />
                
                {/* Rating stars */}
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-wedding-gold fill-current" />
                  ))}
                </div>
                
                {/* Testimonial text */}
                <p className="text-muted-foreground leading-relaxed mb-6 flex-grow italic">
                  "{testimonial.text}"
                </p>
                
                {/* Author info */}
                <div className="border-t border-border pt-6">
                  <h4 className="font-semibold text-card-foreground text-lg">
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                  <p className="text-xs text-wedding-orange mt-1 font-medium">
                    {testimonial.ceremony}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-wedding-cream to-wedding-cream/50 p-8 rounded-2xl">
            <h3 className="text-2xl sm:text-3xl font-bold text-foreground mb-4">
              Join Our Family of Happy Couples
            </h3>
            <p className="text-muted-foreground text-lg mb-6 max-w-2xl mx-auto">
              Over 500 celebrations, countless smiles, and a lifetime of beautiful memories. 
              Let us help you create your own love story.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <div className="text-center px-6">
                <div className="text-3xl font-bold text-wedding-orange">60+</div>
                <div className="text-sm text-muted-foreground">Celebrations</div>
              </div>
              <div className="text-center px-6">
                <div className="text-3xl font-bold text-wedding-magenta">12</div>
                <div className="text-sm text-muted-foreground">Years Experience</div>
              </div>
              <div className="text-center px-6">
                <div className="text-3xl font-bold text-wedding-gold">100%</div>
                <div className="text-sm text-muted-foreground">Happy Families</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
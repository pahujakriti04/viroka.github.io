import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-wedding.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/40" />
      
      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-white mb-6 animate-fade-in">
          Your Love Story,
          <span className="block bg-gradient-to-r from-wedding-gold to-wedding-orange bg-clip-text text-transparent">
            Perfectly Crafted
          </span>
        </h1>
        
        <p className="text-xl sm:text-2xl text-white/90 mb-8 leading-relaxed animate-fade-in">
          Creating magical moments that celebrate the beautiful traditions of Indian weddings. 
          Every detail designed to honor your love and heritage.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in">
          <Button variant="wedding" size="lg" className="text-lg px-8 py-4">
            Book Your Consultation
          </Button>
          <Button variant="elegant" size="lg" className="text-lg px-8 py-4">
            View Our Work
          </Button>
        </div>
      </div>
      
      {/* Floating decorative elements */}
      <div className="absolute top-20 left-10 w-16 h-16 bg-wedding-gold/20 rounded-full animate-float"></div>
      <div className="absolute bottom-20 right-10 w-12 h-12 bg-wedding-magenta/20 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
      <div className="absolute top-1/3 right-20 w-8 h-8 bg-wedding-orange/30 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
    </section>
  );
};

export default HeroSection;
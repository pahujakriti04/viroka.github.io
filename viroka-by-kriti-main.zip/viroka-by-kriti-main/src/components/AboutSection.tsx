import { Heart, Star, Users } from "lucide-react";

const AboutSection = () => {
  return (
    <section className="py-20 bg-gradient-warm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-6">
            A Story of <span className="text-wedding-orange">Passion</span> & <span className="text-wedding-magenta">Purpose</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            For over a decade, I've had the privilege of bringing families together through the sacred tradition of Indian weddings. 
            Every ceremony is a celebration of love, culture, and the beautiful bond between two souls.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="bg-card rounded-2xl p-8 shadow-elegant">
              <Heart className="w-12 h-12 text-wedding-magenta mb-4" />
              <h3 className="text-2xl font-semibold text-card-foreground mb-4">Personal Touch</h3>
              <p className="text-muted-foreground leading-relaxed">
                I believe every couple has a unique love story. My approach focuses on understanding your journey, 
                your traditions, and your dreams to create a celebration that truly reflects who you are.
              </p>
            </div>

            <div className="bg-card rounded-2xl p-8 shadow-elegant">
              <Star className="w-12 h-12 text-wedding-gold mb-4" />
              <h3 className="text-2xl font-semibold text-card-foreground mb-4">Cultural Heritage</h3>
              <p className="text-muted-foreground leading-relaxed">
                Honoring the rich traditions of Indian weddings while seamlessly blending modern elegance. 
                Every ritual, every decoration carries the weight of generations of love and blessing.
              </p>
            </div>

            <div className="bg-card rounded-2xl p-8 shadow-elegant">
              <Users className="w-12 h-12 text-wedding-orange mb-4" />
              <h3 className="text-2xl font-semibold text-card-foreground mb-4">Family First</h3>
              <p className="text-muted-foreground leading-relaxed">
                Your wedding is not just about two people - it's about two families coming together. 
                I ensure every family member feels included, honored, and part of this beautiful celebration.
              </p>
            </div>
          </div>

          <div className="lg:text-right">
            <blockquote className="text-2xl sm:text-3xl italic text-foreground leading-relaxed mb-8">
              "A wedding is not just an event, it's the beginning of a beautiful journey. 
              My role is to ensure that journey starts with the most magical celebration possible."
            </blockquote>
            
            <div className="border-l-4 border-wedding-gold pl-6">
              <p className="text-lg font-semibold text-foreground">Kriti</p>
              <p className="text-muted-foreground">Lead Wedding Designer</p>
              <p className="text-sm text-muted-foreground mt-2">500+ Celebrations • 12 Years of Experience</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
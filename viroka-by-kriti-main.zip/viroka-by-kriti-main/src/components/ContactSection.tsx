import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, Calendar, Heart, Star } from "lucide-react";

const ContactSection = () => {
  return (
    <section className="py-20 bg-gradient-sunset relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full animate-float"></div>
      <div className="absolute bottom-10 right-10 w-16 h-16 bg-white/10 rounded-full animate-float" style={{ animationDelay: '1s' }}></div>
      <div className="absolute top-1/2 left-20 w-8 h-8 bg-white/20 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
      
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">
            Let's Create <span className="text-wedding-cream">Magic</span> Together
          </h2>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Your perfect wedding is just a conversation away. Let's discuss your dreams, 
            your traditions, and how we can make your special day absolutely unforgettable.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Contact Form Card */}
          <Card className="bg-white/95 backdrop-blur-sm shadow-xl border-0">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl font-bold text-foreground flex items-center justify-center gap-2">
                <Heart className="w-6 h-6 text-wedding-magenta" />
                Book Your Consultation
              </CardTitle>
              <p className="text-muted-foreground">
                Let's start planning your dream wedding with a personal consultation
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Bride's Name *
                  </label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-input rounded-lg focus:ring-2 focus:ring-wedding-orange focus:border-transparent transition-colors"
                    placeholder="Enter bride's name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Groom's Name *
                  </label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-input rounded-lg focus:ring-2 focus:ring-wedding-orange focus:border-transparent transition-colors"
                    placeholder="Enter groom's name"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Email Address *
                </label>
                <input 
                  type="email" 
                  className="w-full px-4 py-3 border border-input rounded-lg focus:ring-2 focus:ring-wedding-orange focus:border-transparent transition-colors"
                  placeholder="your.email@example.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Phone Number *
                </label>
                <input 
                  type="tel" 
                  className="w-full px-4 py-3 border border-input rounded-lg focus:ring-2 focus:ring-wedding-orange focus:border-transparent transition-colors"
                  placeholder="+91 9988173194"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Wedding Date (if decided)
                </label>
                <input 
                  type="date" 
                  className="w-full px-4 py-3 border border-input rounded-lg focus:ring-2 focus:ring-wedding-orange focus:border-transparent transition-colors"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Tell us about your dream wedding
                </label>
                <textarea 
                  rows={4}
                  className="w-full px-4 py-3 border border-input rounded-lg focus:ring-2 focus:ring-wedding-orange focus:border-transparent transition-colors resize-none"
                  placeholder="Share your vision, traditions you'd like to include, guest count, preferred locations, or any special requirements..."
                />
              </div>
              
              <Button variant="wedding" className="w-full text-lg py-6">
                <Calendar className="w-5 h-5 mr-2" />
                Schedule Free Consultation
              </Button>
              
              <p className="text-xs text-muted-foreground text-center">
                We'll respond within 24 hours to schedule your personal consultation
              </p>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <div className="text-white">
              <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Star className="w-6 h-6 text-wedding-cream" />
                Get In Touch
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Phone className="w-6 h-6 text-wedding-cream mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-white mb-1">Phone</h4>
                    <p className="text-white/90">+91 9988173194</p>
                    <p className="text-white/70 text-sm">Available 9 AM - 8 PM</p>
                  </div>
                </div>
                
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
              <h4 className="text-white font-semibold text-lg mb-4">Why Choose Us?</h4>
              <ul className="space-y-3 text-white/90">
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-wedding-cream rounded-full flex-shrink-0"></div>
                  12+ years of experience in Indian weddings
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-wedding-cream rounded-full flex-shrink-0"></div>
                  Deep understanding of cultural traditions
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-wedding-cream rounded-full flex-shrink-0"></div>
                  Personalized service for every family
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-wedding-cream rounded-full flex-shrink-0"></div>
                  Network of trusted vendors across India
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
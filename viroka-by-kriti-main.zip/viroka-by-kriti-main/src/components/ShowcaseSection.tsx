import { Card, CardContent } from "@/components/ui/card";
import weddingDecor from "@/assets/wedding-decor-1.jpg";
import weddingCouple from "@/assets/wedding-couple-1.jpg";
import weddingReception from "@/assets/wedding-reception.jpg";

const ShowcaseSection = () => {
  const showcaseItems = [
    {
      image: weddingDecor,
      title: "Traditional Mandap Designs",
      description: "Sacred spaces adorned with marigolds, roses, and intricate drapery that honor ancient traditions.",
      category: "Ceremony"
    },
    {
      image: weddingCouple,
      title: "Intimate Moments",
      description: "Capturing the deep emotions and tender connections that make each love story unique.",
      category: "Photography"
    },
    {
      image: weddingReception,
      title: "Grand Receptions",
      description: "Elegant celebrations that bring families together in joy, laughter, and endless memories.",
      category: "Reception"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-foreground mb-6">
            Moments That <span className="text-wedding-orange">Speak</span> to the <span className="text-wedding-magenta">Heart</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Each celebration is a masterpiece of emotion, tradition, and love. 
            Witness the magic we create together.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {showcaseItems.map((item, index) => (
            <Card key={index} className="group overflow-hidden bg-card hover:shadow-xl transition-all duration-500 hover:-translate-y-2">
              <div className="relative overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-wedding-gold text-white px-3 py-1 rounded-full text-sm font-medium">
                    {item.category}
                  </span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
              
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-card-foreground mb-3 group-hover:text-wedding-orange transition-colors">
                  {item.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {item.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="bg-gradient-sunset p-8 rounded-3xl shadow-warm">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">
              Ready to Create Your Dream Wedding?
            </h3>
            <p className="text-white/90 text-lg mb-6 max-w-2xl mx-auto">
              Let's bring your vision to life with the warmth, beauty, and traditions that make Indian weddings truly magical.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-wedding-orange px-8 py-3 rounded-lg font-semibold hover:bg-wedding-cream transition-colors">
                Schedule Consultation
              </button>
              <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-wedding-orange transition-colors">
                View Full Portfolio
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ShowcaseSection;